Downloaded from https://github.com/lijuncen/Sentiment-and-Style-Transfer/tree/master/data/yelp
